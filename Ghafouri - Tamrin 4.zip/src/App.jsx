import React from 'react'
import Rating from './Components/Rating';

export default function App() {
  return (
    <>
    <Rating/>
        </>
  );
}
